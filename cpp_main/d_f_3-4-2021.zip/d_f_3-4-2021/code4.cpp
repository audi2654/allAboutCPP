#include <iostream>

int main(){

    int x(55);

    if(x == 55 || x > 0)
    std::cout<<"x<=55";
    std::cout<<"x=40";
    std::cout<<"x>=10";

    return 0;
}