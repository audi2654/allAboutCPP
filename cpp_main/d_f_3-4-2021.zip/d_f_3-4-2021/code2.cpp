#include<iostream>

int main(){

    int i = -30, j = 20, k = 1, m;
    
    m = ++i && ++j && --k;      //i:true & j:true & k:false = false, all pre operation

    std::cout<<"Value of i: "<<i<<std::endl;     //-29
    std::cout<<"Value of j: "<<j<<std::endl;     //21
    std::cout<<"Value of k: "<<k<<std::endl;     //0
    std::cout<<"Value of m: "<<m<<std::endl;     //0

    return 0;
}