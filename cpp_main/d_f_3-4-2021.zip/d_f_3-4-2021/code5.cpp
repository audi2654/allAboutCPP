#include <iostream>

int main(){

    int x{3};
    int a = x++ + x++ + ++x;       
    
        //ret temp1 + ret temp2 + x
        //3 + 4 + 6

    std::cout<<"Value of a: "<<a<<std::endl;        //13
    std::cout<<"Value of x: "<<x<<std::endl;        //6

    return 0;
}