#include<iostream>

int main(){

	int i = 3, j;    //decalration + definition + initialization
	j = i++;		 //assignment of i to j, i post incremented

	std::cout<<"Value of i: "<<i<<std::endl; 	//4
	std::cout<<"Value of j: "<<j<<std::endl;	//3

	return 0;
}
