#include<iostream>

int main(){

    int a = 100, b = 200, c;

    c = (a == 100 || b > 200);      //a: true or b:false = true

    std::cout<<"Value of c: "<<c<<std::endl;    //1

    return 0;
}